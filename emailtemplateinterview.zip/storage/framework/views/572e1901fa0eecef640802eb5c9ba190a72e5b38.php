
<div class="avatar av-l"></div>
<p class="info-name"><?php echo e(config('chatify.name')); ?></p>
<div class="messenger-infoView-btns">
    
    <a href="#" class="danger delete-conversation"><i class="fas fa-trash-alt"></i> Delete Conversation</a>
</div>

<div class="messenger-infoView-shared">
    <p class="messenger-title">shared photos</p>
    <div class="shared-photos-list"></div>
</div><?php /**PATH E:\xampp\htdocs\emailtemplateinterview\vendor\munafio\chatify\src/views/layouts/info.blade.php ENDPATH**/ ?>