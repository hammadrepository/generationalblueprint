<template>
    <div>
        <div class="row gutters">

            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                <div class="card m-0">

                    <!-- Row start -->
                    <div class="row no-gutters">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-3 col-3">
                            <div class="users-container bg-light">

                                <ul class="users">
                                    <li class="person" v-for="group1 in groups" :data-chat="'group' + group.id" @click="loadChat(group1.id)">
                                        <div class="user">
                                            <img src="https://www.bootdey.com/img/Content/avatar/avatar3.png" alt="Retail Admin">
                                            <span class="status busy"></span>
                                        </div>
                                        <p class="name-time">
                                            <span class="name">{{ group1.name }}</span>
                                            <span class="time">15/02/2019</span>
                                        </p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-9 col-9">
                            <div class="chat-container">
                                <div class="selected-user">
                                    <span class="name">{{ group.name }}</span>
                                  <span v-show="isLoading" class=" is-overlay">
                                    <i class="fa fa-spinner fa-spin fa-2x fa-fw float-right"></i>
                                  </span>
                                </div>
<!--                                        <span v-show="isLoading" class="loading-overlay is-overlay">-->
<!--                                        <i class="fa fa-cog fa-spin fa-3x fa-fw"></i>-->
<!--                            </span>-->
                                <ul class="chat-box chatContainerScroll" :id="'panel-body-' + group.id">
                                    <li class="text-center">
                                        <button type="button" class="btn btn-link" v-if="this.hasMore" @click="loadMore()">Load more...</button>

                                    </li>
                                    <li v-if="isLoaded" v-for="conversation in conversations"  :class="getClass(conversation.user.id)">
                                        <div class="chat-avatar">
                                            <div v-show="getClass(conversation.user.id) == 'chat-left'">
                                            <img src="https://www.bootdey.com/img/Content/avatar/avatar3.png" alt="Retail Admin">

                                                <div class="chat-name">{{ conversation.user.name }}</div>
                                            </div>
                                        </div>
                                        <div class="chat-text">{{ conversation.message }}</div>
                                        <div class="chat-hour">08:55 <span class="fa fa-check-circle"></span></div>
                                    </li>


                                </ul>
                                <div class="form-group mt-3 mb-0">
                                    <div class="input-group">
                                        <input id="btn-input" type="text" class="form-control input-sm" placeholder="Type your message here..." v-model="message" @keyup.enter="store()" autofocus />
                                        <span class="input-group-btn">
                            <button class="btn btn-warning btn-md" id="btn-chat" @click.prevent="store()">
                                Send  <span v-if="loading" class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></button>
                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>

            </div>

        </div>
<!--    <div class="panel panel-primary">-->
<!--            <div class="panel-heading bg-dark" id="accordion">-->
<!--                <span class="glyphicon glyphicon-comment"></span> {{ group.name }}-->
<!--                <div class="btn-group" @click="loadChat(group.id)">-->
<!--                    <a type="button" class="btn btn-default btn-xs" data-toggle="collapse" data-parent="#accordion-" :href="'#collapseOne-' + group.id" >-->
<!--                        <span class="fa fa-caret-square-down "></span>-->
<!--                    </a>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="panel-collapse collapse" :id="'collapseOne-' + group.id" >-->
<!--                <div class="panel-body chat-panel bg-white" :id="'panel-body-' + group.id">-->
<!--                    <ul class="chat list-group">-->
<!--                        <li class="hover-overlay text-center">-->
<!--                            <button type="button" class="btn btn-link" v-if="this.hasMore" @click="loadMore()">Load more...</button>-->
<!--                        </li>-->
<!--                        <li v-for="conversation in conversations" class="list-group-item list-group-item-light">-->
<!--                        &lt;!&ndash; <span class="chat-img pull-left">-->
<!--                            <img src="http://placehold.it/50/55C1E7/fff&text=U" alt="User Avatar" class="img-circle" />-->
<!--                        </span> &ndash;&gt;-->
<!--                            <div class="chat-body clearfix">-->
<!--                                <div class="header">-->
<!--                                    <strong class="primary-font">{{ conversation.user.name }}</strong>-->
<!--                                </div>-->
<!--                                <p>-->
<!--                                    {{ conversation.message }}-->
<!--                                </p>-->
<!--                            </div>-->
<!--                        </li>-->
<!--                    </ul>-->
<!--                </div>-->
<!--                <div class="panel-footer">-->
<!--                    <div class="input-group">-->
<!--                        <input id="btn-input" type="text" class="form-control input-sm" placeholder="Type your message here..." v-model="message" @keyup.enter="store()" autofocus />-->
<!--                        <span class="input-group-btn">-->
<!--                            <button class="btn btn-warning btn-md" id="btn-chat" @click.prevent="store()">-->
<!--                                Send  <span v-if="loading" class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></button>-->
<!--                        </span>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->


        <!-- Content wrapper end -->
    </div>
</template>

<script>
    export default {
        props: ['allgroups','group','user'],

        data() {
            return {
                conversations: [],
                message: '',
                group_id: this.group.id,
                loading : false,
                next_page_url:'',
                hasMore : false,
                isLoaded : false,
                isLoading: false,
                user1:{},
                groups:[],

            }
        },

        mounted() {
            this.user1 = this.user;
            this.groups = this.allgroups;
            this.loadChat(this.allgroups[0].id);
            this.listenForNewMessage();
        },

        methods: {
            getClass(id){
                if(this.user1.id == id){
                    return 'chat-right';
                }
                return 'chat-left';
            },
            store() {
                this.loading = true;
                axios.post('/conversations', {message: this.message, group_id: this.group.id})
                .then((response) => {
                    this.message = '';
                    this.conversations.push(response.data);
                })
                .catch((error) => {
                    this.message = '';
                    this.loading = false;
                    this.scrollToEnd();
                });

            },
            scrollToEnd: function() {
                var container = this.$el.querySelector("#panel-body-"+this.group.id);
                container.scrollTop = container.scrollHeight;
            },
            loadMore(){
                this.isLoading = true;
                if(this.next_page_url !== null){

                axios.get(this.next_page_url)
                    .then((response) => {
                        if(response.data.next_page_url != null){
                            this.hasMore = true;
                        }else{
                            this.hasMore = false;

                        }
                        for (var i=0; i<response.data.data.length; i++)
                        {
                            this.conversations.unshift(response.data.data[i]);
                        }
                        this.next_page_url = response.data.next_page_url;

                    });
                    this.isLoading = false;
                }
            },
            loadChat(id){
                this.isLoading = true;
              axios.get('/chat/'+id )
              .then((response) => {
                 this.conversations = (response.data.data.reverse());
                 this.next_page_url = response.data.next_page_url;
                 this.next_page_url != null ? this.hasMore = true: this.hasMore = false;
                  this.isLoading = false;
              });

              this.isLoaded = true;
            },
            listenForNewMessage() {

                Echo.private('groups.' + this.group.id)
                    .listen('NewMessage', (e) => {
                        // console.log(JSON.parse(e));
                        console.log('listening');
                        this.conversations.push(e);
                    });

            }
        }
    }
</script>
<style scope>
.loading-overlay {
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(100, 100, 100, .5);
}
.chatContainerScroll{
    overflow-y: scroll;
    height: 550px;
}
.chat-search-box {
    -webkit-border-radius: 3px 0 0 0;
    -moz-border-radius: 3px 0 0 0;
    border-radius: 3px 0 0 0;
    padding: .75rem 1rem;
}

.chat-search-box .input-group .form-control {
    -webkit-border-radius: 2px 0 0 2px;
    -moz-border-radius: 2px 0 0 2px;
    border-radius: 2px 0 0 2px;
    border-right: 0;
}

.chat-search-box .input-group .form-control:focus {
    border-right: 0;
}

.chat-search-box .input-group .input-group-btn .btn {
    -webkit-border-radius: 0 2px 2px 0;
    -moz-border-radius: 0 2px 2px 0;
    border-radius: 0 2px 2px 0;
    margin: 0;
}

.chat-search-box .input-group .input-group-btn .btn i {
    font-size: 1.2rem;
    line-height: 100%;
    vertical-align: middle;
}

@media (max-width: 767px) {
    .chat-search-box {
        display: none;
    }
}


/************************************************
	************************************************
									Users Container
	************************************************
************************************************/

.users-container {
    position: relative;
    padding: 1rem 0;
    border-right: 1px solid #e6ecf3;
    height: 100%;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-direction: column;
    flex-direction: column;
}


/************************************************
	************************************************
											Users
	************************************************
************************************************/

.users {
    padding: 0;
}

.users .person {
    position: relative;
    width: 100%;
    padding: 10px 1rem;
    cursor: pointer;
    border-bottom: 1px solid #f0f4f8;
}

.users .person:hover {
    background-color: #ffffff;
    /* Fallback Color */
    background-image: -webkit-gradient(linear, left top, left bottom, from(#e9eff5), to(#ffffff));
    /* Saf4+, Chrome */
    background-image: -webkit-linear-gradient(right, #e9eff5, #ffffff);
    /* Chrome 10+, Saf5.1+, iOS 5+ */
    background-image: -moz-linear-gradient(right, #e9eff5, #ffffff);
    /* FF3.6 */
    background-image: -ms-linear-gradient(right, #e9eff5, #ffffff);
    /* IE10 */
    background-image: -o-linear-gradient(right, #e9eff5, #ffffff);
    /* Opera 11.10+ */
    background-image: linear-gradient(right, #e9eff5, #ffffff);
}

.users .person.active-group {
    background-color: #ffffff;
    /* Fallback Color */
    background-image: -webkit-gradient(linear, left top, left bottom, from(#f7f9fb), to(#ffffff));
    /* Saf4+, Chrome */
    background-image: -webkit-linear-gradient(right, #f7f9fb, #ffffff);
    /* Chrome 10+, Saf5.1+, iOS 5+ */
    background-image: -moz-linear-gradient(right, #f7f9fb, #ffffff);
    /* FF3.6 */
    background-image: -ms-linear-gradient(right, #f7f9fb, #ffffff);
    /* IE10 */
    background-image: -o-linear-gradient(right, #f7f9fb, #ffffff);
    /* Opera 11.10+ */
    background-image: linear-gradient(right, #f7f9fb, #ffffff);
}

.users .person:last-child {
    border-bottom: 0;
}

.users .person .user {
    display: inline-block;
    position: relative;
    margin-right: 10px;
}

.users .person .user img {
    width: 48px;
    height: 48px;
    -webkit-border-radius: 50px;
    -moz-border-radius: 50px;
    border-radius: 50px;
}

.users .person .user .status {
    width: 10px;
    height: 10px;
    -webkit-border-radius: 100px;
    -moz-border-radius: 100px;
    border-radius: 100px;
    background: #e6ecf3;
    position: absolute;
    top: 0;
    right: 0;
}

.users .person .user .status.online {
    background: #9ec94a;
}

.users .person .user .status.offline {
    background: #c4d2e2;
}

.users .person .user .status.away {
    background: #f9be52;
}

.users .person .user .status.busy {
    background: #fd7274;
}

.users .person p.name-time {
    font-weight: 600;
    font-size: .85rem;
    display: inline-block;
}

.users .person p.name-time .time {
    font-weight: 400;
    font-size: .7rem;
    text-align: right;
    color: #8796af;
}

@media (max-width: 767px) {
    .users .person .user img {
        width: 30px;
        height: 30px;
    }
    .users .person p.name-time {
        display: none;
    }
    .users .person p.name-time .time {
        display: none;
    }
}


/************************************************
	************************************************
									Chat right side
	************************************************
************************************************/

.selected-user {
    width: 100%;
    padding: 0 15px;
    min-height: 64px;
    line-height: 64px;
    border-bottom: 1px solid #e6ecf3;
    -webkit-border-radius: 0 3px 0 0;
    -moz-border-radius: 0 3px 0 0;
    border-radius: 0 3px 0 0;
}

.selected-user span {
    line-height: 100%;
}

.selected-user span.name {
    font-weight: 700;
}

.chat-container {
    position: relative;
    padding: 1rem;
    background-image: url("https://www.wallpapertip.com/wmimgs/106-1060152_world-s-okayest-bard-i-made-a-d.png");
    background-size: contain;
}

.chat-container li.chat-left,
.chat-container li.chat-right {
    display: flex;
    flex: 1;
    flex-direction: row;
    margin-bottom: 40px;
}

.chat-container li img {
    width: 48px;
    height: 48px;
    -webkit-border-radius: 30px;
    -moz-border-radius: 30px;
    border-radius: 30px;
}

.chat-container li .chat-avatar {
    margin-right: 20px;
}

.chat-container li.chat-right {
    justify-content: flex-end;
}

.chat-container li.chat-right > .chat-avatar {
    margin-left: 20px;
    margin-right: 0;
}

.chat-container li .chat-name {
    font-size: .75rem;
    color: #999999;
    text-align: center;
}

.chat-container li .chat-text {
    padding: .4rem 1rem;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    background: #ffffff;
    font-weight: 300;
    line-height: 150%;
    position: relative;
}

.chat-container li .chat-text:before {
    content: '';
    position: absolute;
    width: 0;
    height: 0;
    top: 10px;
    left: -20px;
    border: 10px solid;
    border-color: transparent #ffffff transparent transparent;
}

.chat-container li.chat-right > .chat-text {
    text-align: right;
    max-width: 23rem;
}

.chat-container li.chat-right > .chat-text:before {
    right: -20px;
    border-color: transparent transparent transparent #ffffff;
    left: inherit;
}

.chat-container li .chat-hour {
    padding: 0;
    margin-bottom: 10px;
    font-size: .75rem;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    margin: 0 0 0 15px;
}

.chat-container li .chat-hour > span {
    font-size: 16px;
    color: #9ec94a;
}

.chat-container li.chat-right > .chat-hour {
    margin: 0 15px 0 0;
}

@media (max-width: 767px) {
    .chat-container li.chat-left,
    .chat-container li.chat-right {
        flex-direction: column;
        margin-bottom: 30px;
    }
    .chat-container li img {
        width: 32px;
        height: 32px;
    }
    .chat-container li.chat-left .chat-avatar {
        margin: 0 0 5px 0;
        display: flex;
        align-items: center;
    }
    .chat-container li.chat-left .chat-hour {
        justify-content: flex-end;
    }
    .chat-container li.chat-left .chat-name {
        margin-left: 5px;
    }
    .chat-container li.chat-right .chat-avatar {
        order: -1;
        margin: 0 0 5px 0;
        align-items: center;
        display: flex;
        justify-content: right;
        flex-direction: row-reverse;
    }
    .chat-container li.chat-right .chat-hour {
        justify-content: flex-start;
        order: 2;
    }
    .chat-container li.chat-right .chat-name {
        margin-right: 5px;
    }
    .chat-container li .chat-text {
        font-size: .8rem;
    }
}

.chat-form {
    padding: 15px;
    width: 100%;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ffffff;
    border-top: 1px solid white;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}
.card {
    border: 0;
    background: #f4f5fb;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px;
    margin-bottom: 2rem;
    box-shadow: none;
}
</style>
